import cs50

x = cs50.get_int("x: ")
y = cs50.get_int("y: ")

z = x / y
print(f"{z:.50f}")