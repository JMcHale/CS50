
answer = input("What's your name? ")
print("hello, " + answer)
print(f"hello, {answer}")