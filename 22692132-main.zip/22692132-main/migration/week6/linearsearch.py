import sys

numbers = [4, 5, 2, 1, 19, 4, 0, 12]

if 0 in numbers:
    print("0 was found!")

else:
    print("0 not found, sad")
