#include <stdio.h>

int mergesort(int array[]);

int main(void)
{
    int startarray[] = {3, 1, 9, 14};
    mergesort(startarray);
}

int mergesort(int array[])
{
    
}