#include <stdio.h>

int main(void){
    int x;
    int y;
    printf("X value is: ");
    scanf("%i", &x);
    printf("Y value is: ");
    scanf("%i", &y);
    printf("Sum is %f\n", x + y);
}