#include <stdio.h>

int main(void)
{

    char stringarray[2][15] = {"Hello!", "World!"};

    printf("First String: %s\nSecond String: %s\n", stringarray[0], stringarray[1]);

}